#include <iostream>
#include "taylor_exp_header.h"
#include <cmath>
#include <vector>
int Factorial(int numero){  
   
if(numero<0){    
return(-1);
}    
if(numero==0){    
return(1);
}
else    
{    
return(numero*Factorial(numero-1));

}
}    
double MyExp(double exponent, int num_terms){
    int n{1};
    double suma;
    double valor;
    double resultado_taylor;
    //std::vector<double> lista_de_numeros_taylor;
    //lista_de_numeros_taylor.resize(num_terms);
    while (n<=num_terms){
        suma=pow(n, exponent)/Factorial(n);
        valor+=suma;
        n++;
    }
    resultado_taylor=1+valor;
    return(resultado_taylor);
}
