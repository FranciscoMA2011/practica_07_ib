#include <iostream>
#include "taylor_exp_header.h"
#include <cmath>
int main(){
    double exponente; int numero_terminos;
    std::cout<<"El propósito de este programa es calcular el valor de e elevado a un exponente determinado mediante la serie de Taylor, cuya precisión aumentará según el número de terminos elegido \n";
    std::cout<<"Introduzca el exponente al que desea elevar e: ";
    std::cin>>exponente;
    std::cout<<"Introduzca el número de términos: ";
    std::cin>>numero_terminos;
    std::cout<<"El número e elevado a "<<exponente<<" con "<<numero_terminos<<" términos de precisión es igual a: ";
    std::cout<<MyExp(exponente, numero_terminos);
    std::cout<<"\n";
    double my_exponential=MyExp(exponente, numero_terminos);
    std::cout<<"¿Tienen la exponencial de cmath y esta exponencial el mismo valor? ";
    if (my_exponential==exp(exponente)){
        std::cout<<"Sí que lo tienen";
    }
    else{
        std::cout<<"No lo tienen";
    }
    std::cout<<"\n";
}