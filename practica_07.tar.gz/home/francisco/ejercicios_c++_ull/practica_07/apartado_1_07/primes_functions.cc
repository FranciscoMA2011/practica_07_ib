#include <iostream>
#include <vector>
#include "primes_h_functions.h"
bool IsPrime (int numero){
    int m{2};
    if (numero==1){
        //std::cout<<"El número introducido es igual a 1, no es un primo\n";
        return false;
    }
    while (m<numero){
        if (numero%m==0){
            return false;
            //std::cout<<"El número introducido no es primo: "<<numero<<"\n";
        }
        m++;
    }
    //std::cout<<"El número introducido es primo: "<<numero<<"\n";
    return true;

    }
