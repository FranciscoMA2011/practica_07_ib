#include <iostream>
#include "primes_h_functions.h"
#include <vector>
int main (){
    std::cout<<"Este programa sirve para determinar todos los números primos menores al introducido\n";
    std::cout<<"Introduzca un número: ";
    int numero_introducido;
    std::cin>>numero_introducido;
    int n{1};
    std::vector<int> lista_de_primos_vec;
    while (n<numero_introducido){
        if (IsPrime(n)==true){
            lista_de_primos_vec.emplace_back(n);
            }
        n+=1;
        
    }
    //std::cout<<"El programa ha salido del bucle\n";
    int i=0;
    std::cout<<"La lista de números primos menores al número es: ";
    while (i<int(lista_de_primos_vec.size())){
        std::cout<<lista_de_primos_vec.at(i)<<" ";
        i+=1;
    }
    std::cout<<"\n";
}