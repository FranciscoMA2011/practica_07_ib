#pragma once
bool IsPrime(int numero);