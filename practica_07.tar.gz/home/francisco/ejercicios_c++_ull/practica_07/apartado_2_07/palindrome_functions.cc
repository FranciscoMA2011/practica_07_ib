#include <iostream>
#include "palindrome_header.h"
#include <string>
#include <vector>
bool IsPalindrome(std::string palabra){
        int n;
        int longitud_palabra=int(palabra.length());
        while (n<longitud_palabra){
            if (palabra.at(0)!=palabra.at(longitud_palabra-1)){
                return false;
            }
        n++;
        }
    return true;
}