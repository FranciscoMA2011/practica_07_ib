#include <iostream>
#include "palindrome_header.h"
#include <string>
#include <vector>

int main (){
        std::vector<std::string> palabras_palindromas_vec;
        std::vector<std::string> lista_de_palabras_vec;
        int numero_palabras;
        std::cout<<"La finalidad de este programa es verificar si las palabras introducidas en una lista determinada son palíndromas \n";
        std::cout<<"Introduzca el número de palabras en la lista: ";
        std::cin>>numero_palabras;
        lista_de_palabras_vec.resize(numero_palabras);
        palabras_palindromas_vec.resize(numero_palabras);
        int n=0;
        while (n<numero_palabras){
            std::cout<<"Introduza la palabra número "<<n+1<<" de la lista: ";
            std::cin>>lista_de_palabras_vec.at(n);
            if (IsPalindrome(lista_de_palabras_vec.at(n))==true){
                palabras_palindromas_vec.emplace_back(lista_de_palabras_vec.at(n));
            }
            n++;
        }
        std::cout<<"La lista de palabras palíndromas es: ";
        for (auto i: palabras_palindromas_vec){
            std::cout<<i;
            std::cout<<" ";
        }
        std::cout<<"\n";
}