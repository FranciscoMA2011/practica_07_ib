
bool IsPalindrome(std::string palabra);