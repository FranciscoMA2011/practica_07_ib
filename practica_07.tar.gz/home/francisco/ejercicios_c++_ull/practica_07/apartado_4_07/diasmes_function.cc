#include <iostream>
#include <string>
#include "diasmes_header.h"
int DiasMes(int Mes){
    if (Mes>12){
        return(-1);
    }
    if (Mes== 2){
        return(28);
    }
    if (Mes==1 ||Mes==3||Mes==5||Mes==7||Mes==8||Mes==10||Mes==12){
        return(31);
    }
    else{
        return(30);
    }
}