#include <iostream>
#include "diasmes_header.h"
#include <string>
int main(){
        int mes_introducido;
        std::cout<<"El objetivo de este programa es imprimir en pantalla el número de días que tiene un mes dado\n";
        std::cout<<"Introduzca el mes del que quiera saber los días de forma numérica: ";
        std::cin>>mes_introducido;
        std::cout<<"El número de días en este mes es: "<<DiasMes(mes_introducido);
        std::cout<<"\n";
        //Para tratar correctamente los años bisiestos, debería introducirse un parámetro int año, y si su módulo por cuatro es cero, añadir a febrero un día
}