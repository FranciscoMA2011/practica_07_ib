void OrdenarBorrarElementosRepetidos(std::vector<int> &sortedVector);
std::vector<int> PossiblesMults(int min, int max);
int IntegrosAlReves(int num);
std::vector<int> PalindromeNumbsVector(std::vector<int> mults_vec);
void PrintVector(const std::vector<int> &vector);
void NumberFactors(int num, int min, int max);
