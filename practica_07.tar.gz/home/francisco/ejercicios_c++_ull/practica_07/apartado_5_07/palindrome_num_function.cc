#include <iostream>
#include <algorithm>
#include <vector>
#include "palindrome_num_header.h"

//Usando la librería de algoritmos, se puede borrar y ordenar vectores
void OrdenarBorrarElementosRepetidos(std::vector<int> &sortedVector){
  std::sort(sortedVector.begin(), sortedVector.end());
  auto last = std::unique(sortedVector.begin(), sortedVector.end());
  sortedVector.erase(last, sortedVector.end());
}
//La función encuentra posibles múltiplos en un intervalo(min, max)
std::vector<int> PossiblesMults(int min, int max){
  std::vector<int> rawMultVector;
  for(min; min <= max; min++){
    for(int i = min; i <= max; i++){
      int mult = min * i;
      rawMultVector.emplace_back(mult);  
    }
  }
  OrdenarBorrarElementosRepetidos(rawMultVector);
  return rawMultVector;
}
//Le da la vuelta a un íntegro. Esto se consigue dándose cuenta de que se puede avanzar entre cifras multiplicando por diez
int IntegroAlReves(int num){
  int reversed{0};
  while(num != 0){    
    reversed = reversed * 10 + num % 10;  
    num /= 10;  
  }  
  return reversed;
}
//Dado un vector, halla otro vector con números palíndromos
std::vector<int> PalindromeNumbsVector(std::vector<int> mults_vec){
  std::vector<int> palindromeNumsVec;
  for(auto element: mults_vec){
    int revNum = IntegroAlReves(element);
    if(revNum == element){
      palindromeNumsVec.emplace_back(element);
    }
  }
  return palindromeNumsVec;
}
//Esta función void no tiene un valor de return pero imprime vectores en pantalla
void PrintVector(const std::vector<int> &vector){
  for(auto element: vector){
    std::cout << element << " ";
  }
}
//Dado un número íntegro, un mínimo y un máximo, imprime en pantalla los factores del número
void NumberFactors(int num, int min, int max){
  for(min; min <= max; min++){
    for(int i = min; i <= max; i++){
      if(min * i == num){
        std::cout << "[ " << min << ", " << i << " ] ";
      }
    }
  }
}