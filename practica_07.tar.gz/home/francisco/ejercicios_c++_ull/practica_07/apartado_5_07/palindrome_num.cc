#include <iostream>
#include <algorithm>
#include <vector>
#include "palindrome_num_header.h"



int main(){


  std::vector<int> multVector;
  std::vector<int> palindrome_vec;
  int intInf, intSup;


  std::cout << "Introduzca el intervalo mínimo: ";
  std::cin >> intInf;
  std::cout << "Introduzca el intervalo máximo: ";
  std::cin >> intSup;
  
  multVector = PossiblesMults(intInf, intSup);
  palindrome_vec = PalindromeNumbsVector(multVector);

  std::cout << "\n";
  std::cout << "Vector de múltipos [" << intInf << ", " << intSup << "]\n";
  PrintVector(multVector);
  std::cout << "\n\n";
  if(palindrome_vec.empty()){
    std::cout << "No se encontró un número palíndromo";
    return 0;
  }
  std::cout << "- - - Vector Palíndromo [" << intInf << ", " << intSup << "]- - -\n";
  PrintVector(palindrome_vec);
  std::cout << "\n\n";
  std::cout << "Palíndromo Mayor " << palindrome_vec.back() << " - Factores: ";
  NumberFactors(palindrome_vec.back(), intInf, intSup);
  std::cout <<  "\n";
  std::cout << "Palíndromo Mínimo: " << palindrome_vec.front() << " - Factores: ";
  NumberFactors(palindrome_vec.front(), intInf, intSup);
}